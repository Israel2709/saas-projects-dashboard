export default function Home() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-white text-black dark:bg-zinc-900 dark:text-white transition-colors">
      <h1 className="text-4xl font-bold">Projects Dashboard</h1>
    </main>
  );
}
