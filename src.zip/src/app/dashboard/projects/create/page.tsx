import { createProject } from "./actions";

export default function CreateProjectPage() {
  return (
    <div className="p-8 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Create New Project</h1>
      <form action={createProject} className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">Name</label>
          <input
            name="name"
            type="text"
            required
            className="w-full border rounded px-3 py-2 dark:bg-zinc-900 dark:border-zinc-700"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Description</label>
          <textarea
            name="description"
            rows={4}
            className="w-full border rounded px-3 py-2 dark:bg-zinc-900 dark:border-zinc-700"
          ></textarea>
        </div>
        <button
          type="submit"
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 text-sm"
        >
          Create Project
        </button>
      </form>
    </div>
  );
}
